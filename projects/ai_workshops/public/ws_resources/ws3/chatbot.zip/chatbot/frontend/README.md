# Frontend - AI & Data Science Chatbot Workshop

This is the React frontend for the chatbot.

## Setup
1. Navigate into the `frontend/` folder.
2. Run:
    npm install
    npm start

3. Open browser to http://localhost:3000.

This will connect to the Flask backend running on http://localhost:5000/chat.